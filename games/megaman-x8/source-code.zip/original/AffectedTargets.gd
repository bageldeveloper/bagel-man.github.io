class_name AffectedTargets
