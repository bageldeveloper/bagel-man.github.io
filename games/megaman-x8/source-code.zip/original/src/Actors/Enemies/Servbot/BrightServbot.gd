extends Enemy

